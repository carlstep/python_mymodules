from setuptools import setup

setup(
    name='vsearch2',
    version='1.0',
    description='the head first python search tools',
    author='CS HF Python 2e',
    author_email='carlstep333@me.com',
    url='',
    py_modules=['vsearch2'],
    )